<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class News extends Model
{
    protected $table = "news";
    protected $primaryKey = "id";
    protected $fillable = ['Title', 'Description', 'Link', 'Image', 'Date'];
    public $timestamps = false;
    use HasFactory;
}

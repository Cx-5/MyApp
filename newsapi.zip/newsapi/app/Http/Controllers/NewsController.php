<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Resources\NewsCollection;
use App\Models\News;
use DateTime;
use DOMDocument;
use DOMXpath;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Vedmant\FeedReader\Facades\FeedReader;

class NewsController extends Controller
{
    public function newsFeed(){
        $newsfeedreader = FeedReader::read('https://vnexpress.net/rss/kinh-doanh.rss');
        foreach ($newsfeedreader->get_items(0, $newsfeedreader->get_item_quantity()) as $item){
           //title
            $Title = $item -> get_title();
            //link
            $Link = $item -> get_link();
            //content
            $getData = $item->get_item_tags('', 'description');
            $theData = $getData[0]['data'];
            $explode = explode("</br>", $getData[0]['data']);
            $Content = null;
            if (str_contains($theData, "</br>")){
                $Content = $explode[1];
            }else {
                $Content = $explode[0];
            }
            //image
            $dom = new DOMDocument();
            $dom->loadHTML($item->get_description());
            $xpath = new DOMXPath($dom);
            $Image = $xpath->evaluate("string(//img/@src)");
            //Date
            $rawDate = $item->get_item_tags('', 'pubDate');
            $Date = new DateTime($rawDate[0]['data']);

            $news = News::firstOrNew(
                ['Title' => $Title, 'Description' => $Content, 'Image' => $Image, 'Link' => $Link, 'Date' => $Date],
                ['Title' => $Title, 'Description' => $Content, 'Image' => $Image, 'Link' => $Link, 'Date' => $Date]
            );
            $news->save();
       

        }
       // $data = News::where('Title', $Title)->orderBy('Date', 'DESC')->get();
        return new NewsCollection(News::all());
}
}
package com.example.newsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
EditText username, email, password, passwordConfirm;
Button btnRegister;
String Username, Email, Password, PasswordConfirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        passwordConfirm = findViewById(R.id.passwordConfirm);
        btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkRegister();
            }
        });
    }

    private void checkRegister() {
        Username = username.getText().toString();
        Email = email.getText().toString();
        Password = password.getText().toString();
        PasswordConfirm = passwordConfirm.getText().toString();

        if (Username.isEmpty() || Email.isEmpty() || Password.isEmpty()){
            alertFail("User Name , Email and Password is required");
        }
        else if (!Password.equals(passwordConfirm)){
            alertFail("Password doesn't match.");
        }
        else{
            sentRegister();
        }
    }

    private void sentRegister() {
        alertSuccess("Register is successfully");

    }

    private void alertSuccess(String register_is_successfully) {
        new AlertDialog.Builder(this)
                .setTitle("Success")
                .setIcon(R.drawable.ic_check_box_24)
                .setMessage(register_is_successfully)
                .setPositiveButton("Login", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        onBackPressed();
                    }
                }).show();
    }

    private void alertFail(String s) {
        new AlertDialog.Builder(this)
                .setTitle("Failed")
                .setIcon(R.drawable.ic_warning_24)
                .setMessage(s)
                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).show();
    }
}

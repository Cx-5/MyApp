package com.example.newsapp;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class JSONResponse {

private DataModel[] data;

    public DataModel[] getData() {
        return data;
    }

    public void setData(DataModel[] data) {
        this.data = data;
    }
}

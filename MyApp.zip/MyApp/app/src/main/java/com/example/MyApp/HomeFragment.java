package com.example.MyApp;

import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {


}

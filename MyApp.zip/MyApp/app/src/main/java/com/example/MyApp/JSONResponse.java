package com.example.MyApp;

public class JSONResponse {

    private DataModel[] data;

    public DataModel[] getData() {
        return data;
    }

    public void setData(DataModel[] data) {
        this.data = data;
    }
}

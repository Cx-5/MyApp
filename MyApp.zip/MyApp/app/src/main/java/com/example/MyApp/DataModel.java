package com.example.MyApp;

public class DataModel {
    private int id;
    private String Title;
    private String Link;
    private String Description;
    private String Image;
    private String Date;

    public int getId() {
        return id;
    }
    //getter
    public String getTitle() {
        return Title;
    }

    public String getLink() {
        return Link;
    }

    public String getDescription() {
        return Description;
    }

    public String getImage() {
        return Image;
    }

    public String getDate() {
        return Date;
    }
}

package com.example.MyApp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.fragment.app.FragmentStatePagerAdapter;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;


import android.os.Bundle;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private TabLayout mTabLayout;
    private ViewPager2 mViewpager;
    private ViewPagerAdapter mViewPagerAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        mTabLayout = findViewById(R.id.tabLayout);
        mViewpager = findViewById(R.id.view_pager);
        mViewPagerAdapter  = new ViewPagerAdapter(this);
        mViewpager.setAdapter(mViewPagerAdapter);
        new TabLayoutMediator(mTabLayout, mViewpager, (tab, position) -> {
            switch (position){
                case 0:
                    tab.setText("Trang chủ");
                    break;

                case 1:
                    tab.setText("My News Page");
                    break;
                case 2:
                    tab.setText("BMI");
                    break;
            }
        }).attach();


    }


}